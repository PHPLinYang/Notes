<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/11 0011
 * Time: 10:25
 */
namespace app\admin\controller;


use think\Controller;

class Login extends Controller
{
    public function login()
    {

        return $this->fetch();
    }
}