<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/11 0011
 * Time: 10:25
 */
namespace app\admin\controller;

use app\admin\controller\Base;

class Article extends Base
{
    public function lst()
    {

        return $this->fetch('list');
    }

    public function add()
    {
        return $this->fetch();
    }
}